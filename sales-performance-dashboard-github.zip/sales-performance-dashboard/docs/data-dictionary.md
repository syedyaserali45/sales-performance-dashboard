# Data Dictionary

## Overview
Synthetic sales dataset (2023-2024) - 800 transactions, 12 products, 50 customers, 4 regions. Designed to demonstrate Excel data prep and Power BI modeling without inventing metrics.

## Tables

### 1. Sales (Fact) - 800 rows
| Column | Type | Description | Example |
|--------|------|-------------|---------|
| OrderID | Text | Unique order ID - ORD-YYYY-NNNN | ORD-2023-0001 |
| OrderDate | Date | Transaction date | 2023-05-15 |
| CustomerID | Text | FK to Customers | C001 |
| ProductID | Text | FK to Products | P001 |
| RegionID | Text | FK to Regions | R01 |
| Quantity | Int | Units sold | 1-50 (higher for Office Supplies) |
| UnitPrice | Number | Selling price from Products | 1200 |
| UnitCost | Number | Cost from Products | 700 |
| Discount% | % | Discount applied | 0%, 5%, 10%, 15% |
| SalesAmount | Number | `Quantity * UnitPrice * (1-Discount%)` | 1200 |
| CostAmount | Number | `Quantity * UnitCost` | 700 |
| Profit | Number | `SalesAmount - CostAmount` | 500 |
| Channel | Text | Sales channel | Online, Retail, Distributor |
| SalesRep | Text | Sales representative | Amit Kumar etc |

**Calculations are Excel formulas / M, not hardcoded.**

### 2. Products (Dimension) - 12 rows
| Column | Type | Description |
|--------|------|-------------|
| ProductID | Text | PK |
| ProductName | Text | Product name |
| Category | Text | Electronics, Furniture, Office Supplies |
| UnitCost | Number | Cost |
| UnitPrice | Number | Price |

Products:
- P001 Laptop Pro 14" (Electronics) 700/1200
- P002 Smartphone X (Electronics) 400/750
- P003 Tablet Mini (Electronics) 200/350
- P004 Office Chair Ergo (Furniture) 80/150
- P005 Standing Desk (Furniture) 200/400
- P006 Bookshelf Oak (Furniture) 60/120
- P007 Printer Laser Pro (Electronics) 150/280
- P008 Notebook Pack (Office Supplies) 5/12
- P009 Pen Set Premium (Office Supplies) 8/20
- P010 Monitor 27" 4K (Electronics) 180/320
- P011 Conference Table (Furniture) 350/650
- P012 Supplies Kit Pro (Office Supplies) 10/25

### 3. Regions (Dimension) - 4 rows
| Column | Type | Description |
|--------|------|-------------|
| RegionID | Text | PK - R01 to R04 |
| RegionName | Text | North, South, East, West |
| Manager | Text | Region manager |
| Zone | Text | Zone label |

### 4. Customers (Dimension) - 50 rows
| Column | Type | Description |
|--------|------|-------------|
| CustomerID | Text | PK - C001 to C050 |
| CustomerName | Text | Company/Consumer name (Hyderabad context) |
| Segment | Text | Enterprise, SMB, Consumer |
| RegionID | Text | FK to Regions |

### 5. Calendar (Dimension) - 731 rows
| Column | Type | Description |
|--------|------|-------------|
| Date | Date | 2023-01-01 to 2024-12-31 |
| Year | Int | 2023, 2024 |
| Month | Int | 1-12 |
| MonthName | Text | Jan-Dec |
| Quarter | Text | Q1-Q4 |
| YearMonth | Text | YYYY-MM |

## Relationships (Star Schema)
- Sales[ProductID] -> Products[ProductID] (M:1)
- Sales[RegionID] -> Regions[RegionID] (M:1)
- Sales[CustomerID] -> Customers[CustomerID] (M:1)
- Sales[OrderDate] -> Calendar[Date] (M:1)
- Customers[RegionID] -> Regions[RegionID] (M:1)

## KPIs (No invented metrics)
All derived from Sales fact:
- Total Sales = SUM(SalesAmount)
- Total Cost = SUM(CostAmount)
- Total Profit = SUM(Profit)
- Total Orders = DISTINCTCOUNT(OrderID)
- Avg Order Value = Total Sales / Total Orders
- Profit Margin % = Profit / Sales
- YoY Growth = (2024-2023)/2023
- All category/region/channel breakdowns via CALCULATE + FILTER

## Data Generation Logic
- Quantity: Office Supplies 5-50, Furniture 1-5, Electronics 1-8
- Discount: 62.5% no discount, rest 5/10/15%
- Channel: Online 40%, Retail 35%, Distributor 25% (random.choices weighted)
- Dates: Uniform random 2023-2024 (731 days) with natural Q4 uplift visible in data
- SalesAmount = Qty * Price * (1-Discount) - Excel formula
