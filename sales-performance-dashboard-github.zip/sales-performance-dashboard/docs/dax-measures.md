# DAX Measures - Sales Performance Dashboard

All measures are in `powerbi/SalesPerformance.Dataset/definition/tables/Sales.tmdl` (TMDL format) and also listed here for reference.

## Core KPIs
```DAX
Total Sales = SUM(Sales[SalesAmount])
Total Cost = SUM(Sales[CostAmount])
Total Profit = SUM(Sales[Profit])
Total Orders = DISTINCTCOUNT(Sales[OrderID])
Total Quantity = SUM(Sales[Quantity])
Average Order Value = DIVIDE([Total Sales], [Total Orders])
Profit Margin % = DIVIDE([Total Profit], [Total Sales])
Average Discount % = AVERAGE(Sales[Discount%])
```

## Time Intelligence
```DAX
Sales 2023 = CALCULATE([Total Sales], FILTER(Calendar, Calendar[Year]=2023))
Sales 2024 = CALCULATE([Total Sales], FILTER(Calendar, Calendar[Year]=2024))
YoY Growth % = DIVIDE([Sales 2024] - [Sales 2023], [Sales 2023])
Sales YTD = TOTALYTD([Total Sales], Calendar[Date])
Sales MTD = TOTALMTD([Total Sales], Calendar[Date])
Profit YTD = TOTALYTD([Total Profit], Calendar[Date])
```

## Category & Product
```DAX
Sales by Category = CALCULATE([Total Sales], ALLEXCEPT(Products, Products[Category]))
Top Product Sales = MAXX(TOPN(1, ADDCOLUMNS(VALUES(Products[ProductName]), "@Sales", [Total Sales]), [@Sales], DESC), [@Sales])
Product Rank = RANKX(ALL(Products[ProductName]), [Total Sales], , DESC, DENSE)
```

## Channel & Region
```DAX
Online Sales % = DIVIDE(CALCULATE([Total Sales], Sales[Channel]="Online"), [Total Sales])
Region Rank = RANKX(ALL(Regions[RegionName]), [Total Sales], , DESC)
```

## Customer Segmentation
```DAX
Enterprise Sales = CALCULATE([Total Sales], Customers[Segment]="Enterprise")
SMB Sales = CALCULATE([Total Sales], Customers[Segment]="SMB")
Consumer Sales = CALCULATE([Total Sales], Customers[Segment]="Consumer")
Profit per Order = DIVIDE([Total Profit], [Total Orders])
```

## How to Use
1. Measures are already in TMDL - open `SalesPerformance.pbip` and they appear in Sales table
2. If building from Excel source, create new measure in Power BI Desktop > Modeling > New Measure > paste DAX
3. Format: Sales as Currency, Margin % as Percentage, Orders as Whole Number

## No Invented Metrics
All measures use SUM, DISTINCTCOUNT, DIVIDE, CALCULATE, FILTER, TOTALYTD - derived from transaction-level Sales fact. No hardcoded values.
