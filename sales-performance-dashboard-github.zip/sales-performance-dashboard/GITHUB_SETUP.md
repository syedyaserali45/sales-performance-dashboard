# GitHub Setup Guide

## Quick Start - Push to GitHub

### 1. Create GitHub Repo
- Go to https://github.com/new
- Repo name: `sales-performance-dashboard`
- Description: `Sales Performance Dashboard | Excel + Power BI (PBIP/TMDL/PBIR) - 800 transactions, star schema, DAX, modern Git-friendly format`
- Public, no README (we already have one)
- Create repo

### 2. Push from Local (Terminal in this folder)

```bash
# Initialize git (if not already)
git init

# Add all files
git add .

# First commit
git commit -m "feat: initial commit - sales performance dashboard Excel + Power BI PBIP

- Excel dashboard with 800 transactions, 8 KPIs, 5 charts
- Power BI PBIP project with TMDL/PBIR (modern Git-friendly format)
- 5 tables star schema, 10 DAX measures, 3 report pages
- No invented metrics - all derived from transaction fact"

# Add remote (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/sales-performance-dashboard.git

# Push
git branch -M main
git push -u origin main
```

### 3. Add Topics to GitHub Repo
Go to repo Settings > About > Add topics:
`excel` `power-bi` `pbip` `tmdl` `pbir` `dax` `power-query` `dashboard` `sales-analysis` `business-intelligence` `data-visualization` `portfolio`

### 4. Enable GitHub Pages (Optional for docs)
- Settings > Pages > Source: main branch / docs folder
- Or keep README as landing

### 5. Create Release
- Go to Releases > Create new release
- Tag: v1.0.0
- Title: Sales Performance Dashboard v1.0
- Attach: excel/Sales_Performance_Dashboard_Excel.xlsx and powerbi zip

## What to Show in GitHub

- Pin this repo to your profile
- Add to LinkedIn Featured section with link
- Screenshots in README will render automatically
- PBIP structure shows modern Power BI skills (recruiters love TMDL/PBIR mention)

## Portfolio Description for LinkedIn

**Project Title:** Sales Performance Dashboard | Excel + Power BI

**Description:**
Created a sales-performance dashboard to present business results in a clear, structured format. Analyzed sales trends and product/business performance using Excel-based data preparation and reporting. Used Power BI to visualize KPIs and business trends and make raw information easier to interpret. Demonstrated ability to transform transaction-level information into useful business insights without inventing results or metrics.

Tech: Excel (SUMPRODUCT, charts), Power BI (PBIP/TMDL/PBIR - modern Git-friendly format), DAX (20+ measures), Power Query (M), Star Schema (5 tables, 800 transactions)

GitHub: [your link]

**Skills:** Microsoft Excel, Power BI, DAX, Data Visualization, Business Intelligence

## For Resume

Add GitHub link to resume projects section with bullet from README.md
