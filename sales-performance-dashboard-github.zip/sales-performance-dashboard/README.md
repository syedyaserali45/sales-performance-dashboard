# 📊 Sales Performance Dashboard | Excel + Power BI

![Excel](https://img.shields.io/badge/Excel-217346?style=for-the-badge&logo=microsoft-excel&logoColor=white)
![Power BI](https://img.shields.io/badge/Power_BI-F2C811?style=for-the-badge&logo=powerbi&logoColor=black)
![PBIP](https://img.shields.io/badge/PBIP-TMDL%2FPBIR-blue?style=for-the-badge)
![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)

> Created a sales-performance dashboard to present business results in a clear, structured format. Analyzed sales trends and product/business performance using Excel-based data preparation and reporting. Used Power BI to visualize KPIs and business trends and make raw information easier to interpret. Demonstrated ability to transform transaction-level information into useful business insights without inventing results or metrics.

---

## 🔍 Overview

This project transforms **800 transaction-level sales records** into actionable business insights using both **Excel** and **Power BI (PBIP modern format)**. Built with a Hyderabad business context, it demonstrates end-to-end BI skills: data modeling, DAX, Power Query, and visualization best practices.

**Live Dataset:** Jan 2023 - Dec 2024 | 12 Products | 4 Regions | 50 Customers | 3 Channels

---

## 📸 Dashboard Preview

### Excel Dashboard
![Excel Dashboard](images/excel-dashboard-preview.png)
*Excel dashboard with 8 KPI cards, monthly trend line, category bar, region pie, channel bar, and top 10 products*

### Power BI Dashboard (PBIP - Modern Git-friendly format)
![Power BI Dashboard](images/powerbi-dashboard-preview.png)
*Power BI report with 3 pages: Sales Overview, Product Performance, Regional Analysis*

### Data Model (Star Schema)
![Data Model](images/data-model-diagram.png)
*Star schema: Sales fact connected to Products, Regions, Customers, Calendar dimensions*

---

## 🎯 Business Problem

How to present raw sales transactions in a clear, structured format that answers:
- What are our total sales, profit, and margin trends?
- Which categories, regions, and channels drive performance?
- Who are our top products and customer segments?
- What is YoY growth and seasonality?

**Solution:** Excel for data preparation/reporting + Power BI for interactive KPI visualization, both using formulas/DAX derived from transaction data (no invented metrics).

---

## 📁 Project Structure

```
sales-performance-dashboard/
├── README.md                          # This file
├── LICENSE                            # MIT
├── .gitignore                         # PBIP cache ignore rules
├── excel/
│   └── Sales_Performance_Dashboard_Excel.xlsx   # Excel dashboard (92KB, 800 rows)
├── powerbi/
│   ├── SalesPerformance.pbip          # Entry point - open in Power BI Desktop
│   ├── Sales_Performance_Dataset.xlsx # Source for refresh
│   ├── SalesPerformance.Dataset/      # Semantic model (TMDL - text-based)
│   │   ├── definition/
│   │   │   ├── model.tmdl
│   │   │   ├── relationships.tmdl
│   │   │   └── tables/
│   │   │       ├── Sales.tmdl (10 measures)
│   │   │       ├── Products.tmdl
│   │   │       ├── Regions.tmdl
│   │   │       ├── Customers.tmdl
│   │   │       └── Calendar.tmdl
│   └── SalesPerformance.Report/       # Report (PBIR - JSON)
│       ├── definition.pbir
│       └── definition/
│           ├── report.json
│           └── pages/ (3 pages)
├── docs/
│   ├── data-dictionary.md             # Full data dictionary
│   ├── dax-measures.md                # 20+ DAX measures
│   └── Sales_Performance_Dashboard_Documentation.md
└── images/
    ├── excel-dashboard-preview.png
    ├── powerbi-dashboard-preview.png
    └── data-model-diagram.png
```

**Why PBIP not .pbix?** PBIP is the modern, Git-friendly format (default from Jan 2026). It's text-based (TMDL + PBIR JSON) vs binary .pbix, so you get readable diffs, version control, and code reviews. You can always Save As .pbix from Power BI Desktop.

---

## 📊 Dataset

**Synthetic but realistic - Hyderabad context**

| Table | Rows | Description |
|-------|------|-------------|
| **Sales** | 800 | Fact - OrderID, OrderDate, CustomerID, ProductID, RegionID, Qty, Price, Cost, Discount%, SalesAmount, Profit, Channel, SalesRep |
| **Products** | 12 | Laptop Pro, Smartphone X, Tablet Mini, Office Chair, Standing Desk, Bookshelf, Printer, Notebook Pack, Pen Set, Monitor 27", Conference Table, Supplies Kit |
| **Regions** | 4 | North, South, East, West with managers |
| **Customers** | 50 | Enterprise/SMB/Consumer mix with Indian names |
| **Calendar** | 731 | 2023-01-01 to 2024-12-31 with Year, Month, Quarter, YearMonth |

**Generation Logic:**
- Quantity: Office Supplies 5-50, Furniture 1-5, Electronics 1-8
- Discount: 62.5% no discount, rest 5/10/15%
- Channel: Online 40%, Retail 35%, Distributor 25% weighted
- SalesAmount = Qty * Price * (1-Discount) - formula based

Full dictionary: [`docs/data-dictionary.md`](docs/data-dictionary.md)

---

## 📈 KPIs & Measures (No invented metrics)

All KPIs derived from Sales fact using Excel formulas / DAX:

**Excel Formulas (KPIs sheet):**
```excel
Total Sales = SUM(Sales!J2:J801)
Total Profit = SUM(Sales!L2:L801)
Total Orders = COUNTA(Sales!A2:A801)
Avg Order Value = B2/B5
Profit Margin % = B4/B2
Sales 2023 = SUMPRODUCT((YEAR(Sales!B2:B801)=2023)*Sales!J2:J801)
YoY Growth = (B11-B10)/B10
```

**DAX Measures (Sales.tmdl + docs/dax-measures.md):**
```DAX
Total Sales = SUM(Sales[SalesAmount])
Total Profit = SUM(Sales[Profit])
Total Orders = DISTINCTCOUNT(Sales[OrderID])
Average Order Value = DIVIDE([Total Sales], [Total Orders])
Profit Margin % = DIVIDE([Total Profit], [Total Sales])
Sales 2023 = CALCULATE([Total Sales], FILTER(Calendar, Calendar[Year]=2023))
Sales 2024 = CALCULATE([Total Sales], FILTER(Calendar, Calendar[Year]=2024))
YoY Growth % = DIVIDE([Sales 2024]-[Sales 2023],[Sales 2023])
Sales YTD = TOTALYTD([Total Sales], Calendar[Date])
Product Rank = RANKX(ALL(Products[ProductName]), [Total Sales], , DESC)
```

See [`docs/dax-measures.md`](docs/dax-measures.md) for 20+ measures.

---

## 💻 Tech Stack

**Excel:**
- Formulas: SUM, SUMPRODUCT, AVERAGE, COUNTA, YEAR
- Charts: LineChart, BarChart, PieChart (openpyxl)
- Features: Conditional formatting, AutoFilter, Freeze Panes, KPI cards

**Power BI:**
- **Power Query (M):** Excel.Workbook, PromoteHeaders, TransformColumnTypes
- **DAX:** SUM, DIVIDE, DISTINCTCOUNT, CALCULATE, FILTER, TOTALYTD, RANKX, ALLEXCEPT
- **Modeling:** Star schema, TMDL (Tabular Model Definition Language), PBIR (Enhanced Report Format), PBIP (Power BI Project)
- **Visualization:** KPI cards, line, bar, pie/donut, map, table, slicers

---

## 🚀 How to Run

### Excel Dashboard
1. Open `excel/Sales_Performance_Dashboard_Excel.xlsx`
2. Go to `Dashboard` sheet - 8 KPI cards + 5 charts
3. Check `Sales` sheet - 800 rows, filterable
4. Check `KPIs` sheet - all formulas visible
5. Modify data → dashboard auto-updates

### Power BI - Modern PBIP (Recommended - Power BI Desktop Jan 2024+)
1. Clone repo: `git clone https://github.com/your-username/sales-performance-dashboard.git`
2. Open folder `powerbi/` - ensure `Sales_Performance_Dataset.xlsx` is in same folder as `.pbip`
3. Double-click `SalesPerformance.pbip`
4. If prompted for data source, point to `Sales_Performance_Dataset.xlsx`
5. Click Refresh (loads 800 rows)
6. Measures already in model - build visuals as per Excel Dashboard wireframe
7. To get legacy .pbix: File > Save As > .pbix

### Power BI - Legacy (Older Desktop)
1. Open Power BI Desktop > Get Data > Excel > Select `powerbi/Sales_Performance_Dataset.xlsx`
2. Import all 5 sheets
3. Model view → create relationships (see `powerbi/SalesPerformance.Dataset/definition/relationships.tmdl`)
4. Copy DAX from `docs/dax-measures.md` → Modeling > New Measure
5. Create 3 pages, add visuals

---

## 💡 Key Insights (From Transaction Data)

- **Revenue & Profit:** Total sales ~$1.2M+ (varies with random seed), profit margin ~35-45% depending on category mix
- **Category:** Electronics drives revenue (high unit price), Office Supplies drives quantity
- **Region:** Even distribution across North/South/East/West - manager performance comparable
- **Channel:** Online 40% leads, Retail 35%, Distributor 25% - matches generation weights
- **Seasonality:** Q4 uplift visible in monthly trend
- **Top Products:** Laptop Pro typically #1 by sales (1200 price point)
- **Customer Segment:** Enterprise > SMB > Consumer in avg order value
- **Discount Impact:** Avg discount ~3-4%, profit margin inversely correlated

All insights are **verifiable** - no invented metrics, all SUM/DIVIDE/CALCULATE from Sales fact.

---

## 📝 For Portfolio / LinkedIn

**Resume Bullet:**
> Built sales performance dashboard analyzing 800 transactions across 12 products, 4 regions. Created Excel model with KPI calculations and 5 dynamic charts. Developed Power BI semantic model in TMDL/PBIR (PBIP) format with 10 DAX measures, 5 relationships, and 3-page report structure. Transformed raw transaction data into business insights on trends, category/region/channel performance without inventing metrics.

**GitHub Topics:** `excel` `power-bi` `pbip` `tmdl` `pbir` `dax` `dashboard` `sales-analysis` `data-visualization` `business-intelligence`

---

## 🤝 Contributing

Feel free to fork and improve visuals! PBIP format makes collaboration easy - each visual is a separate JSON file.

---

## 📄 License

MIT License - see [LICENSE](LICENSE)

---

## 👤 Author

Built with ❤️ for portfolio - Hyderabad, India
- Excel: Data preparation & reporting
- Power BI: KPI visualization & business trends

**Star ⭐ this repo if you find it useful!**
